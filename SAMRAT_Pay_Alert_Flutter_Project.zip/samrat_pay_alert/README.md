# SAMRAT Pay Alert (Flutter Edition)
UPI Voice Soundbox with Telugu and English announcements using flutter_tts: ^4.2.3.

## Quick Start:
1. Run `flutter pub get`
2. Connect your Android device via USB
3. Run `flutter run`

## Requirements:
- flutter_tts: ^4.2.3
- Android 11+ requires <queries> intent in AndroidManifest.xml (already included)
