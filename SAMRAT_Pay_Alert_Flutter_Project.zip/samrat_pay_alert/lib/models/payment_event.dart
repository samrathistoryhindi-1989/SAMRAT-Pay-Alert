class PaymentEvent {
  final String id;
  final double amount;
  final String sender;
  final String rawText;
  final DateTime timestamp;
  final bool isTest;
  final String appSource;

  PaymentEvent({
    required this.id,
    required this.amount,
    required this.sender,
    this.rawText = '',
    required this.timestamp,
    this.isTest = false,
    this.appSource = 'SAMRAT Soundbox',
  });

  factory PaymentEvent.testPayment({double amount = 500.0}) {
    return PaymentEvent(
      id: 'test_${DateTime.now().millisecondsSinceEpoch}',
      amount: amount,
      sender: 'Test Customer (Simulated)',
      rawText: 'SIMULATED: Payment of ₹${amount.toInt()} received',
      timestamp: DateTime.now(),
      isTest: true, // Requirement 8: Explicitly marked as simulated test
      appSource: 'SAMRAT Test Simulator',
    );
  }
}
