import 'package:flutter/material.dart';
import '../models/payment_event.dart';
import '../services/tts_service.dart';
import '../theme/app_theme.dart';
import '../widgets/payment_modal.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  bool _isServiceActive = true;
  VoiceLanguage _language = VoiceLanguage.telugu;
  double _volume = 0.85;
  bool _isSpeaking = false;

  PaymentEvent? _activePayment;
  final List<PaymentEvent> _history = [
    PaymentEvent.testPayment(amount: 500.0),
  ];

  @override
  void initState() {
    super.initState();
    TtsService().init();
    TtsService().onSpeechStarted = () {
      if (mounted) setState(() => _isSpeaking = true);
    };
    TtsService().onSpeechCompleted = () {
      if (mounted) setState(() => _isSpeaking = false);
    };
  }

  void _handleTestPayment500() {
    if (!_isServiceActive) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please toggle Payment Alert Service ON first!'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    final testPayment = PaymentEvent.testPayment(amount: 500.0);
    setState(() {
      _activePayment = testPayment;
      _history.insert(0, testPayment);
    });

    _speakAlert(testPayment);
  }

  void _speakAlert(PaymentEvent payment) {
    TtsService().speakPaymentAlert(
      payment: payment,
      language: _language,
      volume: _volume,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.goldPrimary,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.campaign_rounded, color: AppColors.darkBg, size: 20),
            ),
            const SizedBox(width: 12),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'SAMRAT Pay Alert',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                ),
                Text(
                  'UPI Voice Soundbox (flutter_tts)',
                  style: TextStyle(fontSize: 11, color: AppColors.goldPrimary),
                ),
              ],
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          ListView(
            padding: const EdgeInsets.all(16),
            children: [
              // 1. Service Toggle Card
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: AppColors.darkSurface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: _isServiceActive ? AppColors.goldPrimary.withOpacity(0.4) : Colors.white10,
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: _isServiceActive
                            ? AppColors.statusGreen.withOpacity(0.15)
                            : Colors.white10,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        Icons.power_settings_new_rounded,
                        color: _isServiceActive ? AppColors.statusGreen : AppColors.textSecondary,
                        size: 24,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Payment Alert Service',
                            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                          ),
                          Text(
                            _isServiceActive ? 'Active • Ready for voice alerts' : 'Paused',
                            style: TextStyle(
                              fontSize: 12,
                              color: _isServiceActive ? AppColors.statusGreen : AppColors.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Switch(
                      value: _isServiceActive,
                      activeColor: AppColors.goldPrimary,
                      onChanged: (val) => setState(() => _isServiceActive = val),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // 2. Test Payment ₹500 Button (Requirement 5 & 6)
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      AppColors.darkSurface,
                      AppColors.darkCard,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.goldPrimary.withOpacity(0.3)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'INSTANT SOUNDBOX TEST',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: AppColors.goldPrimary,
                            letterSpacing: 0.8,
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppColors.goldPrimary.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Text('SIMULATION', style: TextStyle(fontSize: 10, color: AppColors.goldLight, fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      onPressed: _handleTestPayment500,
                      icon: const Icon(Icons.flash_on_rounded, color: AppColors.darkBg, size: 22),
                      label: const Text(
                        'Test Payment ₹500',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.goldPrimary,
                        foregroundColor: AppColors.darkBg,
                        minimumSize: const Size(double.infinity, 54),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        elevation: 4,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Center(
                      child: Text(
                        _language == VoiceLanguage.telugu
                            ? 'Speaks: "మీకు ఐదు వందల రూపాయలు వచ్చాయి"'
                            : 'Speaks: "You received 500 rupees"',
                        style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // 3. Voice Language Selector (Requirement 5)
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: AppColors.darkSurface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white10),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Voice Language', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        Text('flutter_tts: ^4.2.3', style: TextStyle(fontSize: 11, color: AppColors.goldPrimary)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: () => setState(() => _language = VoiceLanguage.telugu),
                            borderRadius: BorderRadius.circular(12),
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              decoration: BoxDecoration(
                                color: _language == VoiceLanguage.telugu
                                    ? AppColors.goldPrimary
                                    : AppColors.darkCard,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Column(
                                children: [
                                  Text(
                                    'తెలుగు',
                                    style: TextStyle(
                                      color: _language == VoiceLanguage.telugu
                                          ? AppColors.darkBg
                                          : AppColors.textPrimary,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 15,
                                    ),
                                  ),
                                  Text(
                                    'Telugu Voice',
                                    style: TextStyle(
                                      color: _language == VoiceLanguage.telugu
                                          ? AppColors.darkBg.withOpacity(0.8)
                                          : AppColors.textSecondary,
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: InkWell(
                            onTap: () => setState(() => _language = VoiceLanguage.english),
                            borderRadius: BorderRadius.circular(12),
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              decoration: BoxDecoration(
                                color: _language == VoiceLanguage.english
                                    ? AppColors.goldPrimary
                                    : AppColors.darkCard,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Column(
                                children: [
                                  Text(
                                    'English',
                                    style: TextStyle(
                                      color: _language == VoiceLanguage.english
                                          ? AppColors.darkBg
                                          : AppColors.textPrimary,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 15,
                                    ),
                                  ),
                                  Text(
                                    'Standard Voice',
                                    style: TextStyle(
                                      color: _language == VoiceLanguage.english
                                          ? AppColors.darkBg.withOpacity(0.8)
                                          : AppColors.textSecondary,
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // 4. Voice Volume Slider (Requirement 5)
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: AppColors.darkSurface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white10),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Voice Volume', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        Text(
                          '${(_volume * 100).toInt()}%',
                          style: const TextStyle(
                            color: AppColors.goldPrimary,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    Slider(
                      value: _volume,
                      activeColor: AppColors.goldPrimary,
                      inactiveColor: AppColors.darkCard,
                      onChanged: (v) => setState(() => _volume = v),
                    ),
                  ],
                ),
              ),
            ],
          ),

          // Payment Modal Overlay
          if (_activePayment != null)
            PaymentModal(
              payment: _activePayment!,
              language: _language,
              isSpeaking: _isSpeaking,
              onDismiss: () {
                TtsService().stop();
                setState(() => _activePayment = null);
              },
              onReplay: () {
                _speakAlert(_activePayment!);
              },
            ),
        ],
      ),
    );
  }
}
