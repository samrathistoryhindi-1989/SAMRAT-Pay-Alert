import '../models/payment_event.dart';

class PaymentNotificationParser {
  static const Map<String, String> knownPaymentPackages = {
    'com.phonepe.app': 'PhonePe',
    'com.phonepe.app.business': 'PhonePe Business',
    'com.google.android.apps.nbu.paisa.user': 'Google Pay',
    'net.one97.paytm': 'Paytm',
    'in.org.npci.upiapp': 'BHIM UPI',
    'com.bharatpe.app': 'BharatPe',
    'com.cred.android': 'CRED',
    'com.amazon.mShop.android.shopping': 'Amazon Pay',
  };

  static final List<RegExp> amountRegexes = [
    RegExp(r'(?:received|credited|payment of|got|rs\.?|inr|₹)\s*([0-9]+(?:,[0-9]{2,3})*(?:\.[0-9]{1,2})?)', caseSensitive: false),
    RegExp(r'₹\s*([0-9]+(?:,[0-9]{2,3})*(?:\.[0-9]{1,2})?)'),
    RegExp(r'rs\.?\s*([0-9]+(?:,[0-9]{2,3})*(?:\.[0-9]{1,2})?)', caseSensitive: false),
  ];

  static final RegExp senderRegex = RegExp(
    r'(?:from|by)\s+([A-Za-z0-9 ]{2,30}?)(?:\s+(?:on|via|ref|using|upi)|\.|,|$)',
    caseSensitive: false,
  );

  static bool isPaymentNotification(String packageName, String title, String text) {
    final combined = '$title $text'.toLowerCase();
    final isKnown = knownPaymentPackages.containsKey(packageName);
    final hasKeywords = combined.contains('received') ||
        combined.contains('credited') ||
        combined.contains('has sent you') ||
        combined.contains('paid you');
    return isKnown && hasKeywords;
  }

  static PaymentEvent? parse(String packageName, String title, String text) {
    final combined = '$title $text';
    final amount = extractAmount(combined);
    if (amount == null) return null;

    final sender = extractSender(combined) ?? 'Customer';
    final appName = knownPaymentPackages[packageName] ?? 'UPI App';

    return PaymentEvent(
      id: 'pay_${DateTime.now().millisecondsSinceEpoch}',
      amount: amount,
      sender: sender,
      rawText: combined,
      timestamp: DateTime.now(),
      isTest: false,
      appSource: appName,
    );
  }

  static double? extractAmount(String text) {
    for (final reg in amountRegexes) {
      final match = reg.firstMatch(text);
      if (match != null) {
        final raw = match.group(1)?.replaceAll(',', '');
        if (raw != null) {
          final val = double.tryParse(raw);
          if (val != null && val > 0) return val;
        }
      }
    }
    return null;
  }

  static String? extractSender(String text) {
    final match = senderRegex.firstMatch(text);
    if (match != null) {
      final candidate = match.group(1)?.trim();
      if (candidate != null && candidate.isNotEmpty) return candidate;
    }
    return null;
  }
}
