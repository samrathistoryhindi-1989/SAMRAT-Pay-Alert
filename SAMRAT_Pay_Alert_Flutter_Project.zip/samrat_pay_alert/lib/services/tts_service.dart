import 'dart:async';
import 'dart:io' show Platform;
import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../models/payment_event.dart';

enum VoiceLanguage {
  telugu('te-IN', 'Telugu', 'తెలుగు'),
  english('en-IN', 'English', 'English');

  final String code;
  final String displayName;
  final String nativeName;
  const VoiceLanguage(this.code, this.displayName, this.nativeName);
}

class TtsService {
  static final TtsService _instance = TtsService._internal();
  factory TtsService() => _instance;
  TtsService._internal();

  final FlutterTts _flutterTts = FlutterTts();
  bool _isInitialized = false;

  VoidCallback? onSpeechStarted;
  VoidCallback? onSpeechCompleted;

  Future<void> init() async {
    if (_isInitialized) return;

    try {
      // Natural cadence and pitch for retail payment announcements
      await _flutterTts.setSpeechRate(0.46);
      await _flutterTts.setPitch(1.0);
      await _flutterTts.setVolume(1.0);

      if (Platform.isAndroid) {
        // High priority audio stream for payment announcements
        await _flutterTts.setAudioAttributes(
          audioAttributes: {
            'usage': 5, // USAGE_ASSISTANCE_SONIFICATION
            'contentType': 1, // CONTENT_TYPE_SPEECH
          },
        );
        // Wait for utterance completion
        await _flutterTts.awaitSynthCompletion(true);
      }

      _flutterTts.setStartHandler(() {
        onSpeechStarted?.call();
      });

      _flutterTts.setCompletionHandler(() {
        onSpeechCompleted?.call();
      });

      _flutterTts.setErrorHandler((msg) {
        debugPrint("flutter_tts error: $msg");
        onSpeechCompleted?.call();
      });

      _isInitialized = true;
    } catch (e) {
      debugPrint("Error initializing flutter_tts: $e");
    }
  }

  /// Speaks the payment alert with exact phrases specified in SAMRAT requirements
  Future<void> speakPaymentAlert({
    required PaymentEvent payment,
    required VoiceLanguage language,
    required double volume,
  }) async {
    await init();
    await _flutterTts.setVolume(volume.clamp(0.0, 1.0));

    String speechText;

    if (language == VoiceLanguage.telugu) {
      // Check if Telugu engine is installed on Android device
      final dynamic isAvailable = await _flutterTts.isLanguageAvailable('te-IN');
      if (isAvailable == true || isAvailable == 1) {
        await _flutterTts.setLanguage('te-IN');
        // Exact Telugu phrase
        speechText = payment.amount == 500.0
            ? "మీకు ఐదు వందల రూపాయలు వచ్చాయి"
            : "మీకు ${payment.amount.toInt()} రూపాయలు వచ్చాయి";
      } else {
        // Fallback to English if Telugu voice data is missing
        await _flutterTts.setLanguage('en-IN');
        speechText = payment.amount == 500.0
            ? "You received 500 rupees"
            : "You received ${payment.amount.toInt()} rupees";
      }
    } else {
      await _flutterTts.setLanguage('en-IN');
      // Exact English phrase
      speechText = payment.amount == 500.0
          ? "You received 500 rupees"
          : "You received ${payment.amount.toInt()} rupees";
    }

    // Stop any ongoing speech and announce
    await _flutterTts.stop();
    await _flutterTts.speak(speechText);
  }

  Future<void> stop() async {
    await _flutterTts.stop();
  }
}
