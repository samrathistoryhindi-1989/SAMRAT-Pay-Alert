import 'package:flutter/material.dart';

class AppColors {
  static const Color darkBg = Color(0xFF0A0C11);
  static const Color darkSurface = Color(0xFF121622);
  static const Color darkCard = Color(0xFF181E2B);
  static const Color goldPrimary = Color(0xFFFFB703);
  static const Color amberAccent = Color(0xFFFB8500);
  static const Color goldLight = Color(0xFFFFE49E);
  static const Color textPrimary = Color(0xFFF8FAFC);
  static const Color textSecondary = Color(0xFF94A3B8);
  static const Color statusGreen = Color(0xFF10B981);
}

class AppTheme {
  static ThemeData get darkTheme {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.darkBg,
      primaryColor: AppColors.goldPrimary,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.goldPrimary,
        secondary: AppColors.amberAccent,
        surface: AppColors.darkSurface,
      ),
      fontFamily: 'Roboto',
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.darkSurface,
        elevation: 0,
      ),
    );
  }
}
