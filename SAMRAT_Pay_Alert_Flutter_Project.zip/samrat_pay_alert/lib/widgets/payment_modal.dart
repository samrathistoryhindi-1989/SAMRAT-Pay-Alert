import 'package:flutter/material.dart';
import '../models/payment_event.dart';
import '../services/tts_service.dart';
import '../theme/app_theme.dart';

class PaymentModal extends StatelessWidget {
  final PaymentEvent payment;
  final VoiceLanguage language;
  final bool isSpeaking;
  final VoidCallback onDismiss;
  final VoidCallback onReplay;

  const PaymentModal({
    super.key,
    required this.payment,
    required this.language,
    required this.isSpeaking,
    required this.onDismiss,
    required this.onReplay,
  });

  @override
  Widget build(BuildContext context) {
    final phrase = language == VoiceLanguage.telugu
        ? "మీకు ఐదు వందల రూపాయలు వచ్చాయి"
        : "You received 500 rupees";

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.darkSurface,
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: AppColors.goldPrimary.withOpacity(0.4), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.8),
              blurRadius: 30,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Close Button
            Align(
              alignment: Alignment.topRight,
              child: IconButton(
                icon: const Icon(Icons.close, color: AppColors.textSecondary),
                onPressed: onDismiss,
              ),
            ),

            // Requirement 8: Simulated Test Payment Badge
            if (payment.isTest) ...[
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: AppColors.amberAccent.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: AppColors.amberAccent.withOpacity(0.6)),
                ),
                child: const Text(
                  '⚠️ SIMULATED TEST PAYMENT',
                  style: TextStyle(
                    color: AppColors.goldPrimary,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'No real bank transaction occurred',
                style: TextStyle(color: AppColors.textSecondary, fontSize: 11),
              ),
              const SizedBox(height: 16),
            ],

            // Soundbox Icon
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.goldPrimary.withOpacity(0.15),
                border: Border.all(color: AppColors.goldPrimary, width: 2),
              ),
              child: Icon(
                isSpeaking ? Icons.volume_up_rounded : Icons.check_circle_rounded,
                color: AppColors.goldPrimary,
                size: 38,
              ),
            ),
            const SizedBox(height: 12),

            const Text(
              'Payment Received',
              style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
            ),

            // Requirement 6: Display ₹500 prominently
            Text(
              '₹${payment.amount.toInt()}',
              style: const TextStyle(
                color: AppColors.goldPrimary,
                fontSize: 48,
                fontWeight: FontWeight.w900,
                letterSpacing: -1,
              ),
            ),
            const SizedBox(height: 16),

            // Voice Text Container
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.darkCard,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white.withOpacity(0.08)),
              ),
              child: Column(
                children: [
                  Text(
                    '"$phrase"',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Announced in ${language.displayName} (${language.nativeName}) via flutter_tts',
                    style: const TextStyle(color: AppColors.textSecondary, fontSize: 11),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Action Buttons
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: onReplay,
                    icon: const Icon(Icons.replay_rounded, size: 18, color: AppColors.goldPrimary),
                    label: const Text('Replay', style: TextStyle(color: AppColors.goldPrimary, fontWeight: FontWeight.bold)),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: AppColors.goldPrimary),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: onDismiss,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.goldPrimary,
                      foregroundColor: AppColors.darkBg,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text('Done', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
